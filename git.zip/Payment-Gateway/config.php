<?php
    
    $razor_pay_key_id = 'rzp_live_ykPL0KfoECSN6h';
    $secret_key = '382NeEeEFfHJG3urmSdwaGWi';
    define("KEY",$razor_pay_key_id);
    define("API_SECRET",$secret_key);
?>