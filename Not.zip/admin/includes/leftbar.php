	<nav class="ts-sidebar">
		<ul class="ts-sidebar-menu">

			<li class="ts-label">Main</li>
			<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			<li><a href="finance.php"><i class="fa fa-users"></i> Userlist</a>
			</li>
			<li><a href="fin.php"><i class="fa fa-users"></i> Unpaid</a>
			</li>
			<li><a href="search.php"><i class="fa fa-search"></i> &nbsp;Search</a>
			</li>
			<li><a href="finance.php"><i class="fa fa-money"></i> &nbsp;Finance</a>
			</li>
			<li><a href="download.php"><i class="fa fa-download"></i> &nbsp;Download</a>
			</li>
		</ul>
		<p class="text-center" style="color:#ffffff; margin-top: 100px;">© 404ISTE</p>
	</nav>
