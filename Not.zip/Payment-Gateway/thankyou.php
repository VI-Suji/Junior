<!DOCTYPE html>
<html>
<head>
<title>Thank You - ISTE TKMCE</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
</head>
<body>
    <article class="bg-secondary mb-3">
    <div class="jumbotron text-center">
  <h1 class="display-3">Thank You!</h1>
  <p class="lead"><strong> Thank you for being one of us </strong> </p>
  <hr>
  <!--
  <p>
    Having trouble? </p> <a href="wwww.istetkmce.in/contact.php">Contact us</a>
  -->
  <p class="lead">
    <a class="btn btn-primary btn-sm" href="https://join.istetkmce.in/login.php" role="button">Continue to homepage</a>
<i class="fa fa-window-restore "></i>
  </p>
  </article>
</div>

</body>